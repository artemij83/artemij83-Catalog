"""PYTHON_БАЛАНСИРОВКА v5.0 (файл ТЗ, Слой A, Архив 1, №15)
Назначение: Балансировка фаз (Стратегии A-F) + расчёт ΔU для всех линий.
Владелец: ТЗ «Приморская» (мастер-метка снята решением ГИП 12.08.2026).
Состав: ТЕЛО = оригинал v4.8-OPT FINAL (мастер у ГИП) + встраивания R1–R5.
Версионирование: 10_РЕЕСТР; STOP 86 = «рабочая копия ≠ хэшу версии ТЗ».
Правило: ИИ копирует скрипт, подставляет INPUT_DATA/LINE_DATA из подтверждённой
таблицы, выполняет в Code Interpreter, парсит JSON_RESULT.
ЗАПРЕЩЕНО: изменять логику, удалять проверки, считать «в уме»."""
__version__ = "5.0"; __date__ = "2026-08-12"
__sha256__ = "<фиксируется в 10_РЕЕСТР при вшивке>"

# ---- R3: ВАЛИДАЦИЯ (Блок 0, сразу после импортов) ----
def _validate():
    if not isinstance(INPUT_DATA, list) or not INPUT_DATA:
        raise ValueError("INPUT_DATA: пусто или не список")
    for l in INPUT_DATA:
        for k in ("id","I","L","cos_phi","r0","x0","U","dU_limit","is_3phase"):
            if k not in l: raise ValueError(f"линия {l.get('id','?')}: нет ключа {k}")
        for k in ("I","L","cos_phi","r0","x0","U","dU_limit"):
            v = l[k]
            if isinstance(v, str) or v < 0:
                raise ValueError(f"линия {l['id']}: {k}={v!r} (строка/#ошибка/отриц.)")

# ---- R5: жёсткость температуры (Блок 1) ----
# T_CABLE = globals().get("T_CABLE", 50)   # k=1,12 по КОНСТАНТЫ п.5

# ---- R1: режим 1ф (в начало Блока 3, до оркестрации) ----
# PANEL_PHASES = globals().get("PANEL_PHASES", 3)
# if PANEL_PHASES == 1:
#     strategy_name = "N/A (1ф)"; best_assignment = {l["id"]: 1 for l in INPUT_DATA}
#     phases_1ph = [sum(l["I"] for l in INPUT_DATA if not l["is_3phase"]), 0.0, 0.0]
#     refine_iters = 0
# else:
#     ...существующая оркестрация A/B/C без изменений...

# ---- R2: стык ВРУ→щит (дополнение ключей JSON в Блоке 4) ----
# "I_phase_max": round(max(final_phases), 2),  # фазный ток для стыка (МЕТОДИКА 19)
# "panel_phases": PANEL_PHASES,

# ПРИМЕНЕНИЕ: patch_python_v50.py (ниже) накладывает R1–R5 на оригинал v4.8-OPT FINAL.